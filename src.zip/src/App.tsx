import { BrowserRouter, Routes, Route } from "react-router-dom";

import Welcome from "./pages/Welcome";
import Compass from "./pages/Compass";
import PathPreview from "./pages/PathPreview";
import Roadmap from "./pages/Roadmap";
import StationDetail from "./pages/StationDetail";
import Checkpoint from "./pages/Checkpoint";
import Navigator from "./pages/Navigator";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Welcome />} />
        <Route path="/compass" element={<Compass />} />
        <Route path="/preview" element={<PathPreview />} />
        <Route path="/roadmap" element={<Roadmap />} />
        <Route path="/station" element={<StationDetail />} />
        <Route path="/checkpoint" element={<Checkpoint />} />
        <Route path="/navigator" element={<Navigator />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;