import { useNavigate } from "react-router-dom";

function StationDetail(){

const navigate=useNavigate();

return(

<div className="page">

<h1>Potensi Diri</h1>

<ul>

<li>✅ Catat 3 kelebihanmu</li>

<li>✅ Tanya temanmu</li>

<li>✅ Tentukan target minggu ini</li>

</ul>

<button onClick={()=>navigate("/checkpoint")}>

Selesai

</button>

</div>

)

}

export default StationDetail;