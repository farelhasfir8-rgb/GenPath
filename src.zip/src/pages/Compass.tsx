import { useNavigate } from "react-router-dom";

function Compass() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <h1>🧭 The Compass</h1>

      <p>Di bagian hidupmu mana yang sedang terasa membingungkan?</p>

      <button onClick={() => navigate("/preview")}>
        🎓 Masa Depanku
      </button>

      <button>
        ❤️ Diriku & Orang Lain
      </button>

      <button>
        🌎 Peranku di Masyarakat
      </button>
    </div>
  );
}

export default Compass;