import { useNavigate } from "react-router-dom";

function Roadmap() {

const navigate = useNavigate();

return (

<div className="page">

<h1>🚇 Roadmap</h1>

<h3>Finish</h3>

<p>○</p>

<p>|</p>

<p>○ Mentor</p>

<p>|</p>

<p>○ Skill Building</p>

<p>|</p>

<p>○ Mental Readiness</p>

<p>|</p>

<p>🟢 Potensi Diri</p>

<button onClick={()=>navigate("/station")}>
Mulai Stasiun
</button>

</div>

)

}

export default Roadmap;