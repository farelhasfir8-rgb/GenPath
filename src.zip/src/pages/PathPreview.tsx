import { useNavigate } from "react-router-dom";

function PathPreview() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <h1>Masa Depanku</h1>

      <h3>5 Stasiun</h3>

      <ul>
        <li>Kenali Potensi Diri</li>
        <li>Mental Readiness</li>
        <li>Skill Building</li>
        <li>Mentorship</li>
        <li>Finish</li>
      </ul>

      <button onClick={() => navigate("/roadmap")}>
        Mulai Perjalanan →
      </button>
    </div>
  );
}

export default PathPreview;