function Navigator(){

return(

<div className="page">

<h1>🤝 Navigator</h1>

<h2>Kak Duta GenRe</h2>

<button>

Chat WhatsApp

</button>

<br/>

<br/>

<button>

Cari PIK-R Terdekat

</button>

</div>

)

}

export default Navigator;