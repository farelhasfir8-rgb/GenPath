import { useNavigate } from "react-router-dom";
import "../styles/welcome.css";

function Welcome() {
  const navigate = useNavigate();

  return (
    <main className="welcome-page">
      <div className="glass-card">
        <span className="badge">🌱 GenPath</span>

        <h1>Mapping Better Decisions</h1>

        <p>
          Setiap perjalanan besar dimulai dari satu langkah kecil.
          <br />
          Mari petakan masa depanmu bersama GenPath.
        </p>

        <button onClick={() => navigate("/compass")}>
          Mulai Melangkah →
        </button>
      </div>
    </main>
  );
}

export default Welcome;