import { useNavigate } from "react-router-dom";

function Checkpoint(){

const navigate=useNavigate();

return(

<div className="page">

<h1>😊 Checkpoint</h1>

<h2>Bagaimana perjalananmu?</h2>

<button>

😀 Lancar

</button>

<button onClick={()=>navigate("/navigator")}>

😔 Aku Butuh Teman Bicara

</button>

</div>

)

}

export default Checkpoint;